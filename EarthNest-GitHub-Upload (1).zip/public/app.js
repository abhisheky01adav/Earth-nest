// Shared helpers for the storefront + login page
const $ = (s, r = document) => r.querySelector(s);
const inr = n => '₹' + Number(n).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const tok = () => localStorage.getItem('en_token');
const me = () => { try { return JSON.parse(localStorage.getItem('en_user')); } catch { return null; } };
async function api(url, opt = {}) {
  const h = { 'Content-Type': 'application/json' }; if (tok()) h.Authorization = 'Bearer ' + tok();
  const r = await fetch(url, { method: opt.method || 'GET', headers: h, body: opt.body ? JSON.stringify(opt.body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && tok()) logout(true); throw new Error(d.error || 'Something went wrong'); }
  return d;
}
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2200); }
function logout(silent) { localStorage.removeItem('en_token'); localStorage.removeItem('en_user'); if (!silent) location.href = '/'; }
const getCart = () => JSON.parse(localStorage.getItem('en_cart') || '[]');
const setCart = c => { localStorage.setItem('en_cart', JSON.stringify(c)); badge(); };
function badge() { const n = getCart().reduce((s, i) => s + i.qty, 0), b = $('#badge'); if (b) { b.textContent = n; b.hidden = !n; } }
function chrome() {
  const u = me();
  $('#hdr').innerHTML = `<header><div class="wrap hd"><nav><a href="/#/">Home</a><a href="/#/shop">Shop Catalog</a><a href="/#/journal">Journal</a></nav>
  <a class="logo" href="/#/">EARTHNEST<small>Sustainable Living</small></a>
  <div class="ic">${u ? `<a href="/#/orders">👤 ${esc(u.name.split(' ')[0])}</a>${u.role === 'admin' ? '<a href="/admin.html">Admin</a>' : ''}<button class="link" id="lo">Logout</button>` : '<a href="/login.html">👤 Login</a>'}
  <a href="/#/cart" class="cartb">🛍️<i id="badge" hidden>0</i></a></div></div></header>`;
  $('#ftr').innerHTML = `<footer><div class="wrap ft"><div><h3>EARTHNEST</h3><p>Handcrafted, earth-first home essentials designed for intentional, timeless living.</p></div>
  <div><h4>Explore</h4><ul><li><a href="/#/shop">All Products</a></li><li><a href="/#/journal">Sustainability Journal</a></li><li><a href="/#/orders">My Orders</a></li></ul></div>
  <div><h4>Customer Care</h4><ul><li>UPI & Bank Transfer Support</li><li>Cash on Delivery Available</li><li>7-day Returns & Exchange</li></ul></div></div>
  <div class="copy">&copy; 2026 EarthNest Eco Store. All rights reserved.</div></footer>`;
  $('#lo')?.addEventListener('click', () => logout());
  badge();
}
async function init() { chrome(); if (tok()) { try { localStorage.setItem('en_user', JSON.stringify(await api('/api/me'))); chrome(); } catch {} } }
